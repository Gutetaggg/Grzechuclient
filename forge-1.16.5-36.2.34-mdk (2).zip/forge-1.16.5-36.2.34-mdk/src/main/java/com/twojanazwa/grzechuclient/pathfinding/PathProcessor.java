package com.twojanazwa.grzechuclient.pathfinding;

import com.twojanazwa.grzechuclient.modules.movement.PathfindingModule;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.DoorBlock;
import net.minecraft.block.FenceGateBlock;
import net.minecraft.client.Minecraft;
import net.minecraft.util.Direction;
import net.minecraft.util.math.BlockPos;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class PathProcessor {

    private final Minecraft mc = Minecraft.getInstance();
    private final BlockPos startPos;
    private final BlockPos goalPos;
    private final PathfindingModule parentModule;
    private final int maxIterations = 6000;

    public PathProcessor(BlockPos start, BlockPos goal, PathfindingModule parentModule) {
        this.startPos = start;
        this.goalPos = goal;
        this.parentModule = parentModule;
    }

    public PathResult findPath() {
        if (mc.level == null) return PathResult.failure(PathResult.FailureReason.NO_PATH_FOUND);

        if (mc.level.getBlockState(goalPos).isSolidRender(mc.level, goalPos)) {
            return PathResult.failure(PathResult.FailureReason.GOAL_OBSTRUCTED);
        }

        List<PathNode> openSet = new ArrayList<>();
        Set<PathNode> closedSet = new HashSet<>();

        PathNode startNode = new PathNode(startPos);
        startNode.setGCost(0);
        startNode.setHCost(calculateHeuristic(startNode));
        startNode.calculateFCost();
        openSet.add(startNode);

        int iterations = 0;
        while (!openSet.isEmpty() && iterations < maxIterations) {
            iterations++;
            PathNode currentNode = getLowestFCostNode(openSet);

            if (currentNode.getPos().distManhattan(goalPos) <= 1) {
                return PathResult.success(reconstructPath(currentNode));
            }

            openSet.remove(currentNode);
            closedSet.add(currentNode);

            for (PathNode neighbor : getNeighbors(currentNode)) {
                if (closedSet.contains(neighbor)) continue;

                double tentativeGCost = currentNode.getGCost() + getMovementCost(currentNode.getPos(), neighbor.getPos());

                if (tentativeGCost < neighbor.getGCost() || !openSet.contains(neighbor)) {
                    neighbor.setParent(currentNode);
                    neighbor.setGCost(tentativeGCost);
                    neighbor.setHCost(calculateHeuristic(neighbor));
                    neighbor.calculateFCost();

                    if (!openSet.contains(neighbor)) {
                        openSet.add(neighbor);
                    }
                }
            }
        }

        if (iterations >= maxIterations) {
            return PathResult.failure(PathResult.FailureReason.TIMEOUT);
        } else {
            return PathResult.failure(PathResult.FailureReason.NO_PATH_FOUND);
        }
    }

    private double getMovementCost(BlockPos from, BlockPos to) {
        double cost = from.distManhattan(to);
        if (mc.level == null) return cost;

        BlockState blockState = mc.level.getBlockState(to);
        if (blockState.is(Blocks.WATER)) cost *= 2.5;
        if (blockState.is(Blocks.SOUL_SAND)) cost *= 4.0;
        if (blockState.is(Blocks.ICE) || blockState.is(Blocks.PACKED_ICE) || blockState.is(Blocks.BLUE_ICE)) cost *= 0.8;

        if (Math.abs(from.getX() - to.getX()) > 1 || Math.abs(from.getZ() - to.getZ()) > 1) {
            cost *= 1.5;
        }

        // Unikanie "Head-hitterów" - dodajemy koszt za niski sufit
        if (parentModule.avoidHeadHitters.isEnabled() && mc.level.getBlockState(to.above(2)).isSolidRender(mc.level, to.above(2))) {
            cost += 5.0; // Duży koszt, aby zniechęcić algorytm
        }

        return cost;
    }

    private List<BlockPos> reconstructPath(PathNode endNode) {
        List<BlockPos> path = new ArrayList<>();
        PathNode currentNode = endNode;
        while (currentNode != null) {
            path.add(currentNode.getPos());
            currentNode = currentNode.getParent();
        }
        Collections.reverse(path);
        return path;
    }

    private List<PathNode> getNeighbors(PathNode node) {
        List<PathNode> neighbors = new ArrayList<>();
        if (mc.level == null) return neighbors;

        BlockPos pos = node.getPos();

        for (Direction direction : Direction.Plane.HORIZONTAL) {
            BlockPos adjacentPos = pos.relative(direction);

            BlockPos downPos = findGround(adjacentPos);
            if (downPos != null) {
                int fallDistance = adjacentPos.getY() - downPos.getY();
                if (!parentModule.avoidFallDamage.isEnabled() || fallDistance <= 3) {
                    if (isPassable(downPos)) {
                        neighbors.add(new PathNode(downPos));
                    }
                }
            }

            if (isPassable(adjacentPos) && isPassable(adjacentPos.above()) && isPassable(pos.above(2))) {
                neighbors.add(new PathNode(adjacentPos.above()));
            }
        }

        if (mc.level.getBlockState(pos).is(Blocks.LADDER)) {
            if (isPassable(pos.above())) neighbors.add(new PathNode(pos.above()));
            if (isPassable(pos.below())) neighbors.add(new PathNode(pos.below()));
        }

        if (parentModule.parkour.isEnabled()) {
            for (Direction direction : Direction.Plane.HORIZONTAL) {
                BlockPos gapCheckPos = pos.relative(direction);
                if (mc.level.isEmptyBlock(gapCheckPos) && mc.level.isEmptyBlock(gapCheckPos.below())) {
                    for (int i = 2; i <= 3; i++) {
                        BlockPos landPos = pos.relative(direction, i);
                        if (isPassable(landPos) && !mc.level.getBlockState(landPos.below()).isAir()) {
                            neighbors.add(new PathNode(landPos));
                            break;
                        }
                    }
                }
            }
        }
        return neighbors;
    }

    private BlockPos findGround(BlockPos startPos) {
        if (mc.level == null) return null;
        BlockPos currentPos = startPos;

        if (!mc.level.getBlockState(currentPos.below()).isAir()) {
            return currentPos;
        }

        for (int i = 0; i < 20; i++) {
            currentPos = currentPos.below();
            if (!mc.level.getBlockState(currentPos.below()).isAir()) {
                return currentPos;
            }
        }
        return null;
    }

    private boolean isPassable(BlockPos pos) {
        if (mc.level == null) return false;
        BlockState state = mc.level.getBlockState(pos);
        if (parentModule.autoOpenDoors.isEnabled() && (state.getBlock() instanceof DoorBlock || state.getBlock() instanceof FenceGateBlock)) {
            return true;
        }
        return !state.isSolidRender(mc.level, pos);
    }

    private double calculateHeuristic(PathNode node) {
        if (parentModule.algorithm.getMode().equals("Szybki")) {
            return node.getPos().distManhattan(goalPos);
        } else {
            return node.getPos().distSqr(goalPos);
        }
    }

    private PathNode getLowestFCostNode(List<PathNode> list) {
        PathNode lowest = list.get(0);
        for (int i = 1; i < list.size(); i++) {
            if (list.get(i).getFCost() < lowest.getFCost()) {
                lowest = list.get(i);
            }
        }
        return lowest;
    }
}
