package com.twojanazwa.grzechuclient.settings;

import com.twojanazwa.grzechuclient.modules.Module;

public class Setting {
    private final String name;
    private final Module parent;

    public Setting(String name, Module parent) {
        this.name = name;
        this.parent = parent;
    }

    public String getName() {
        return name;
    }

    public Module getParent() {
        return parent;
    }
}