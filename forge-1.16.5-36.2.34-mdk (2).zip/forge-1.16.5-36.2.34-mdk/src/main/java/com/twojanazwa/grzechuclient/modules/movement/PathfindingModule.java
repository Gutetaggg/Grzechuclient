package com.twojanazwa.grzechuclient.modules.movement;

import com.twojanazwa.grzechuclient.GrzechuClient;
import com.twojanazwa.grzechuclient.modules.Module;
import com.twojanazwa.grzechuclient.pathfinding.PathExecutor;
import com.twojanazwa.grzechuclient.pathfinding.PathProcessor;
import com.twojanazwa.grzechuclient.pathfinding.PathResult;
import com.twojanazwa.grzechuclient.pathfinding.PathSmoother;
import com.twojanazwa.grzechuclient.settings.BooleanSetting;
import com.twojanazwa.grzechuclient.settings.DoubleSetting;
import com.twojanazwa.grzechuclient.settings.ModeSetting;
import com.twojanazwa.grzechuclient.util.ChatUtil;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import java.util.List;

public class PathfindingModule extends Module {

    private final PathExecutor executor;
    public final BooleanSetting avoidHeadHitters = new BooleanSetting("Unikaj Sufitów", this, true);
    public final BooleanSetting unstuckJump = new BooleanSetting("Skok Anti-Stuck", this, true);
    public final BooleanSetting autoOpenDoors = new BooleanSetting("Otwieraj Drzwi", this, true);
    public final BooleanSetting avoidFallDamage = new BooleanSetting("Unikaj Upadków", this, true);
    public final ModeSetting algorithm = new ModeSetting("Algorytm", this, "Dokładny", "Dokładny", "Szybki");
    public final BooleanSetting parkour = new BooleanSetting("Parkour", this, false);
    public final DoubleSetting jumpHeight = new DoubleSetting("Siła Skoku", this, 0.42, 0.2, 0.42);
    public final DoubleSetting rotationSpeed = new DoubleSetting("Szybkość Obrotu", this, 0.2, 0.05, 1.0);
    public final DoubleSetting corneringFactor = new DoubleSetting("Ścinanie Zakrętów", this, 0.5, 0.0, 1.0);
    public final DoubleSetting slowdownFactor = new DoubleSetting("Zwalnianie", this, 0.4, 0.0, 1.0);
    public final DoubleSetting headNodStrength = new DoubleSetting("Kiwanie Głową", this, 0.5, 0.0, 2.0);
    public final DoubleSetting headShakeStrength = new DoubleSetting("Drganie Głowy", this, 0.5, 0.0, 2.0);

    public PathfindingModule() {
        super("Pathfinding");
        addSetting(avoidHeadHitters);
        addSetting(unstuckJump);
        addSetting(autoOpenDoors);
        addSetting(avoidFallDamage);
        addSetting(algorithm);
        addSetting(parkour);
        addSetting(jumpHeight);
        addSetting(rotationSpeed);
        addSetting(corneringFactor);
        addSetting(slowdownFactor);
        addSetting(headNodStrength);
        addSetting(headShakeStrength);
        this.executor = new PathExecutor(this);
    }

    public PathExecutor getExecutor() {
        return executor;
    }

    public void findAndSetPath(BlockPos goal) {
        if (mc.player == null || mc.level == null) return;

        BlockPos start = mc.player.blockPosition();
        final World world = mc.level;

        new Thread(() -> {
            PathProcessor processor = new PathProcessor(start, goal, this);
            PathResult result = processor.findPath();

            if (result.isSuccessful()) {
                List<BlockPos> rawPath = result.getPath().get();
                List<BlockPos> smoothedPath = PathSmoother.smooth(rawPath, world);

                ChatUtil.sendClientMessage("Ścieżka zoptymalizowana z " + rawPath.size() + " do " + smoothedPath.size() + " punktów.");

                mc.execute(() -> {
                    executor.setPath(smoothedPath);
                    GrzechuClient.client.getModuleManager().getPathRendererModule().setPath(smoothedPath);
                });
            } else {
                result.getFailureReason().ifPresent(reason -> ChatUtil.sendClientMessage(reason.getMessage()));
                mc.execute(() -> {
                    executor.stop();
                    GrzechuClient.client.getModuleManager().getPathRendererModule().setPath(null);
                });
            }
        }).start();
    }

    public void onTick() {
        if (executor.isActive()) {
            executor.onTick();
        }
    }

    public void stopPathing() {
        executor.stop();
        GrzechuClient.client.getModuleManager().getPathRendererModule().setPath(null);
    }

    @Override
    public void onDisable() {
        stopPathing();
    }
}