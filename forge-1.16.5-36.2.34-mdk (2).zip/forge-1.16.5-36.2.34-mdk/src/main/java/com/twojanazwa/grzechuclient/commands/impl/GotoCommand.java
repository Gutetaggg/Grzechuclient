package com.twojanazwa.grzechuclient.commands.impl;

import com.twojanazwa.grzechuclient.GrzechuClient;
import com.twojanazwa.grzechuclient.commands.Command;
import com.twojanazwa.grzechuclient.modules.movement.PathfindingModule;
import com.twojanazwa.grzechuclient.util.ChatUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.util.math.BlockPos;

public class GotoCommand extends Command {

    public GotoCommand() {
        // Dodajemy alias "g"
        super("goto", "Nawiguje do podanych koordynatów.", "g");
    }

    @Override
    public void execute(String[] args) {
        // ... reszta kodu bez zmian
        if (args.length < 2) {
            ChatUtil.sendClientMessage("Użycie: /goto <x> <z> lub /goto <x> <y> <z>");
            return;
        }

        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;

        try {
            int x = Integer.parseInt(args[0]);
            int y = (int) mc.player.getY();
            int z;

            if (args.length > 2) {
                y = Integer.parseInt(args[1]);
                z = Integer.parseInt(args[2]);
            } else {
                z = Integer.parseInt(args[1]);
            }

            BlockPos goal = new BlockPos(x, y, z);
            ChatUtil.sendClientMessage("Obliczam ścieżkę do X: " + x + ", Y: " + y + ", Z: " + z);

            PathfindingModule pathfinder = GrzechuClient.client.getModuleManager().getPathfindingModule();
            pathfinder.findAndSetPath(goal);

        } catch (NumberFormatException e) {
            ChatUtil.sendClientMessage("Podane koordynaty są nieprawidłowe.");
        }
    }
}