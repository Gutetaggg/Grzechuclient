package com.twojanazwa.grzechuclient.core.managers;

import com.twojanazwa.grzechuclient.modules.Module;
import com.twojanazwa.grzechuclient.modules.movement.PathfindingModule;
import com.twojanazwa.grzechuclient.modules.render.HudModule;
import com.twojanazwa.grzechuclient.modules.render.PathRendererModule;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public class ModuleManager {

    private final Map<Class<? extends Module>, Module> modules = new HashMap<>();

    public ModuleManager() {
        addModule(new PathfindingModule());
        addModule(new PathRendererModule());
        addModule(new HudModule()); // Dodajemy nowy moduł
    }

    private void addModule(Module module) {
        modules.put(module.getClass(), module);
    }

    @SuppressWarnings("unchecked")
    public <T extends Module> T getModule(Class<T> clazz) {
        return (T) modules.get(clazz);
    }

    public Collection<Module> getModules() {
        return modules.values();
    }

    public PathfindingModule getPathfindingModule() {
        return getModule(PathfindingModule.class);
    }

    public PathRendererModule getPathRendererModule() {
        return getModule(PathRendererModule.class);
    }

    public HudModule getHudModule() {
        return getModule(HudModule.class);
    }
}
