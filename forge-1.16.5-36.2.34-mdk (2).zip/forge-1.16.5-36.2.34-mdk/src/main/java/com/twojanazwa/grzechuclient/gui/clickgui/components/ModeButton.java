package com.twojanazwa.grzechuclient.gui.clickgui.components;

import com.mojang.blaze3d.matrix.MatrixStack;
import com.twojanazwa.grzechuclient.gui.clickgui.Component;
import com.twojanazwa.grzechuclient.settings.ModeSetting;
import net.minecraft.client.gui.AbstractGui;
import java.awt.Color;

public class ModeButton extends Component {
    private final ModeSetting setting;

    public ModeButton(ModeSetting setting) {
        this.setting = setting;
        this.width = 90;
        this.height = 15;
    }

    @Override
    public void render(MatrixStack matrixStack, int mouseX, int mouseY, float partialTicks) {
        AbstractGui.fill(matrixStack, x, y, x + width, y + height, new Color(10, 10, 10, 180).getRGB());
        String text = setting.getName() + ": " + setting.getMode();
        mc.font.draw(matrixStack, text, x + 3, y + 4, Color.WHITE.getRGB());
    }

    @Override
    public void mouseClicked(double mouseX, double mouseY, int button) {
        if (isMouseOver(mouseX, mouseY) && button == 0) {
            setting.cycle();
        }
    }
}
