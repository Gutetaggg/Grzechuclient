package com.twojanazwa.grzechuclient.settings;

import com.twojanazwa.grzechuclient.modules.Module;

public class DoubleSetting extends Setting {
    private double value;
    private final double min, max;

    public DoubleSetting(String name, Module parent, double value, double min, double max) {
        super(name, parent);
        this.value = value;
        this.min = min;
        this.max = max;
    }

    public double getValue() {
        return value;
    }

    public void setValue(double value) {
        this.value = Math.max(min, Math.min(max, value));
    }

    public double getMin() {
        return min;
    }

    public double getMax() {
        return max;
    }
}
