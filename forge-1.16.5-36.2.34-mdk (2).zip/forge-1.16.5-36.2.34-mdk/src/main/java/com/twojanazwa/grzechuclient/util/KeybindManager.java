package com.twojanazwa.grzechuclient.util;

import org.lwjgl.glfw.GLFW;
import java.util.ArrayList;
import java.util.List;

public class KeybindManager {

    public static class Keybind {
        private final String name;
        private int key;

        public Keybind(String name, int defaultKey) {
            this.name = name;
            this.key = defaultKey;
        }

        public String getName() {
            return name;
        }

        public int getKey() {
            return key;
        }

        public void setKey(int key) {
            this.key = key;
        }
    }

    private final List<Keybind> keybinds = new ArrayList<>();
    public final Keybind openGui = new Keybind("Otwórz GUI", GLFW.GLFW_KEY_RIGHT_SHIFT);
    public final Keybind pausePath = new Keybind("Pauza", GLFW.GLFW_KEY_P);

    public KeybindManager() {
        keybinds.add(openGui);
        keybinds.add(pausePath);
    }

    public List<Keybind> getKeybinds() {
        return keybinds;
    }
}