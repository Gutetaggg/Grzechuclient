package com.twojanazwa.grzechuclient.gui.clickgui.components;

import com.mojang.blaze3d.matrix.MatrixStack;
import com.twojanazwa.grzechuclient.gui.clickgui.Component;
import com.twojanazwa.grzechuclient.util.KeybindManager;
import net.minecraft.client.gui.AbstractGui;
import org.lwjgl.glfw.GLFW;
import java.awt.Color;

public class KeybindButton extends Component {
    private final KeybindManager.Keybind keybind;
    private boolean listening = false;

    public KeybindButton(KeybindManager.Keybind keybind) {
        this.keybind = keybind;
        this.width = 90;
        this.height = 15;
    }

    @Override
    public void render(MatrixStack matrixStack, int mouseX, int mouseY, float partialTicks) {
        AbstractGui.fill(matrixStack, x, y, x + width, y + height, new Color(10, 10, 10, 180).getRGB());
        String text;
        if (listening) {
            text = "Wciśnij klawisz...";
        } else {
            int key = keybind.getKey();
            String keyName = (key == GLFW.GLFW_KEY_UNKNOWN) ? "NONE" : GLFW.glfwGetKeyName(key, 0);
            if (keyName == null) {
                keyName = "KEY_" + key;
            }
            text = keybind.getName() + ": " + keyName.toUpperCase();
        }
        mc.font.draw(matrixStack, text, x + 3, y + 4, Color.WHITE.getRGB());
    }

    @Override
    public void mouseClicked(double mouseX, double mouseY, int button) {
        if (isMouseOver(mouseX, mouseY) && button == 0) {
            listening = !listening;
        }
    }

    @Override
    public void keyTyped(int keyCode, int scanCode, int modifiers) {
        if (listening) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
                keybind.setKey(GLFW.GLFW_KEY_UNKNOWN); // Ustawia na "NONE" po wciśnięciu ESC
            } else {
                keybind.setKey(keyCode);
            }
            listening = false;
        }
    }
}