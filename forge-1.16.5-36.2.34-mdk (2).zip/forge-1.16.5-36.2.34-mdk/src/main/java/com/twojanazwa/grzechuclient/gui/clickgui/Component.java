package com.twojanazwa.grzechuclient.gui.clickgui;

import com.mojang.blaze3d.matrix.MatrixStack;
import net.minecraft.client.Minecraft;

public abstract class Component {
    protected final Minecraft mc = Minecraft.getInstance();
    public int x, y, width, height;

    public abstract void render(MatrixStack matrixStack, int mouseX, int mouseY, float partialTicks);
    public abstract void mouseClicked(double mouseX, double mouseY, int button);

    public void mouseReleased(double mouseX, double mouseY, int button) {}
    public void keyTyped(int keyCode, int scanCode, int modifiers) {}
    public void mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {}

    public boolean isMouseOver(double mouseX, double mouseY) {
        return mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + height;
    }
}