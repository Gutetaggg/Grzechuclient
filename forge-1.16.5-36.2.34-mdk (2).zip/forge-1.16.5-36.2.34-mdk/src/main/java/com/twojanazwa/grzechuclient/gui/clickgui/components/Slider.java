package com.twojanazwa.grzechuclient.gui.clickgui.components;

import com.mojang.blaze3d.matrix.MatrixStack;
import com.twojanazwa.grzechuclient.gui.clickgui.Component;
import com.twojanazwa.grzechuclient.settings.DoubleSetting;
import net.minecraft.client.gui.AbstractGui;
import net.minecraft.util.math.MathHelper;
import java.awt.Color;
import java.math.BigDecimal;
import java.math.RoundingMode;

public class Slider extends Component {
    private final DoubleSetting setting;
    private boolean dragging = false;

    public Slider(DoubleSetting setting) {
        this.setting = setting;
        this.width = 90;
        this.height = 15;
    }

    @Override
    public void render(MatrixStack matrixStack, int mouseX, int mouseY, float partialTicks) {
        double min = setting.getMin();
        double max = setting.getMax();
        double value = setting.getValue();
        double renderWidth = (width * (value - min)) / (max - min);

        // Tło suwaka
        AbstractGui.fill(matrixStack, x, y, x + width, y + height, new Color(10, 10, 10, 180).getRGB());
        // Wypełnienie suwaka
        AbstractGui.fill(matrixStack, x, y, x + (int) renderWidth, y + height, new Color(70, 70, 200, 200).getRGB());

        // Tekst
        String text = setting.getName() + ": " + round(value, 2);
        mc.font.draw(matrixStack, text, x + 3, y + 4, Color.WHITE.getRGB());
    }

    @Override
    public void mouseClicked(double mouseX, double mouseY, int button) {
        if (isMouseOver(mouseX, mouseY) && button == 0) {
            dragging = true;
        }
    }

    @Override
    public void mouseReleased(double mouseX, double mouseY, int button) {
        if (button == 0) {
            dragging = false;
        }
    }

    @Override
    public void mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (dragging && button == 0) {
            double diff = mouseX - x;
            double percent = MathHelper.clamp(diff / width, 0, 1);
            double newValue = setting.getMin() + (setting.getMax() - setting.getMin()) * percent;
            setting.setValue(newValue);
        }
    }

    private static double round(double value, int places) {
        if (places < 0) throw new IllegalArgumentException();
        BigDecimal bd = new BigDecimal(Double.toString(value));
        bd = bd.setScale(places, RoundingMode.HALF_UP);
        return bd.doubleValue();
    }
}