package com.twojanazwa.grzechuclient.commands.impl;

import com.twojanazwa.grzechuclient.GrzechuClient;
import com.twojanazwa.grzechuclient.commands.Command;

public class StopCommand extends Command {
    public StopCommand() {
        super("stop", "Zatrzymuje aktualną nawigację.");
    }

    @Override
    public void execute(String[] args) {
        // Zatrzymujemy nawigację przez moduł
        GrzechuClient.client.getModuleManager().getPathfindingModule().stopPathing();
    }
}