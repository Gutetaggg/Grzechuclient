package com.twojanazwa.grzechuclient.pathfinding;

import net.minecraft.client.Minecraft;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceContext;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraft.world.World;
import java.util.ArrayList;
import java.util.List;

// Ta klasa odpowiada za wygładzanie "kwadratowej" ścieżki z algorytmu A*.
public class PathSmoother {

    private static final Minecraft mc = Minecraft.getInstance();

    public static List<BlockPos> smooth(List<BlockPos> path, World world) {
        if (path == null || path.size() <= 2) {
            return path; // Nie ma czego wygładzać
        }

        List<BlockPos> smoothedPath = new ArrayList<>();
        smoothedPath.add(path.get(0)); // Zawsze zaczynamy od punktu startowego

        int i = 0;
        while (i < path.size() - 1) {
            BlockPos currentPoint = path.get(i);
            BlockPos lastVisiblePoint = null;

            // Szukamy najdalszego punktu na ścieżce, do którego jest prosta droga
            for (int j = i + 1; j < path.size(); j++) {
                BlockPos nextPoint = path.get(j);
                if (hasClearLineOfSight(currentPoint, nextPoint, world)) {
                    lastVisiblePoint = nextPoint;
                } else {
                    break; // Przeszkoda na drodze, przerywamy szukanie
                }
            }

            if (lastVisiblePoint != null) {
                smoothedPath.add(lastVisiblePoint);
                // Przeskakujemy do ostatniego widocznego punktu
                i = path.indexOf(lastVisiblePoint);
            } else {
                // Sytuacja awaryjna, jeśli nie widać nawet następnego punktu
                smoothedPath.add(path.get(i + 1));
                i++;
            }
        }
        return smoothedPath;
    }

    // Sprawdza, czy między dwoma punktami nie ma przeszkód
    private static boolean hasClearLineOfSight(BlockPos start, BlockPos end, World world) {
        Vector3d startVec = new Vector3d(start.getX() + 0.5, start.getY() + 0.5, start.getZ() + 0.5);
        Vector3d endVec = new Vector3d(end.getX() + 0.5, end.getY() + 0.5, end.getZ() + 0.5);

        // Używamy wbudowanego w Minecrafta ray-tracingu
        RayTraceContext context = new RayTraceContext(
                startVec,
                endVec,
                RayTraceContext.BlockMode.COLLIDER, // Sprawdzaj kolizję z blokami
                RayTraceContext.FluidMode.NONE,    // Ignoruj płyny
                mc.player
        );

        // Jeśli wynik "miss" (pudło), to znaczy, że nie ma przeszkód
        return world.clip(context).getType() == net.minecraft.util.math.RayTraceResult.Type.MISS;
    }
}