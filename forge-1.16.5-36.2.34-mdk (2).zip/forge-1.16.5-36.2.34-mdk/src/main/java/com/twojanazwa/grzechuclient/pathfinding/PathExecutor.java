package com.twojanazwa.grzechuclient.pathfinding;

import com.twojanazwa.grzechuclient.modules.movement.PathfindingModule;
import com.twojanazwa.grzechuclient.util.ChatUtil;
import com.twojanazwa.grzechuclient.util.RotationUtil;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.DoorBlock;
import net.minecraft.block.FenceGateBlock;
import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.network.play.client.CPlayerTryUseItemOnBlockPacket;
import net.minecraft.util.Direction;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.BlockRayTraceResult;
import net.minecraft.util.math.vector.Vector3d;
import java.util.List;

public class PathExecutor {
    private final Minecraft mc = Minecraft.getInstance();
    private final PathfindingModule parentModule;
    private List<BlockPos> path;
    private int currentIndex;
    private boolean active = false;
    private boolean paused = false;

    private Vector3d lastPos;
    private int ticksStuck;

    public PathExecutor(PathfindingModule parentModule) {
        this.parentModule = parentModule;
    }

    public List<BlockPos> getPath() { return path; }
    public int getCurrentIndex() { return currentIndex; }
    public boolean isPaused() { return paused; }

    public void togglePause() {
        if (!active) return;
        this.paused = !this.paused;
        if (this.paused) {
            KeyBinding.releaseAll();
        }
    }

    public void setPath(List<BlockPos> path) {
        if (path == null || path.isEmpty()) {
            stop();
            return;
        }
        this.path = path;
        this.currentIndex = 0;
        this.active = true;
        this.paused = false;

        if (mc.player != null) {
            this.lastPos = mc.player.position();
        } else {
            this.lastPos = Vector3d.ZERO;
        }
        this.ticksStuck = 0;

        KeyBinding.releaseAll();
    }

    public void stop() {
        if (!active) return;

        this.active = false;
        this.paused = false;
        this.path = null;
        KeyBinding.releaseAll();
        ChatUtil.sendClientMessage("Nawigacja zatrzymana.");
    }

    public boolean isActive() {
        return active;
    }

    public void onTick() {
        if (!active || paused || mc.player == null || path == null || mc.level == null) {
            return;
        }

        if (currentIndex >= path.size()) {
            ChatUtil.sendClientMessage("Dotarłem do celu!");
            stop();
            return;
        }

        // Logika utknięcia
        if (mc.player.position().distanceToSqr(lastPos) < 0.001 * 0.001) { // Mniejsza tolerancja
            ticksStuck++;
        } else {
            ticksStuck = 0;
            lastPos = mc.player.position();
        }

        // Długie utknięcie -> zatrzymaj
        if (ticksStuck > 60) {
            ChatUtil.sendClientMessage("Utknąłem! Zatrzymuję nawigację.");
            stop();
            return;
        }

        // Krótkie utknięcie -> spróbuj podskoczyć
        if (parentModule.unstuckJump.isEnabled() && ticksStuck > 20 && mc.player.isOnGround()) {
            mc.player.jumpFromGround();
            ticksStuck = 0; // Resetujemy licznik, aby nie skakał w nieskończoność
        }

        checkForDoors();

        BlockPos currentPos = mc.player.blockPosition();
        BlockPos targetPos = path.get(currentIndex);

        boolean isParkourJump = Math.abs(currentPos.getX() - targetPos.getX()) > 1 || Math.abs(currentPos.getZ() - targetPos.getZ()) > 1;

        if (isParkourJump) {
            handleParkourJump(currentPos, targetPos);
        } else {
            handleStandardMovement(targetPos);
        }

        double waypointThreshold = mc.player.isSprinting() ? 1.2 : 0.9;
        if (mc.player.position().distanceToSqr(new Vector3d(targetPos.getX() + 0.5, targetPos.getY() + 0.5, targetPos.getZ() + 0.5)) < waypointThreshold) {
            currentIndex++;
        }
    }

    private void handleStandardMovement(BlockPos targetPos) {
        Vector3d rotationTarget = new Vector3d(targetPos.getX() + 0.5, targetPos.getY() + 0.5, targetPos.getZ() + 0.5);
        if (currentIndex < path.size() - 1) {
            BlockPos nextTargetPos = path.get(currentIndex + 1);
            Vector3d nextTargetVec = new Vector3d(nextTargetPos.getX() + 0.5, nextTargetPos.getY() + 0.5, nextTargetPos.getZ() + 0.5);
            double distanceToCurrent = mc.player.position().distanceTo(rotationTarget);
            double interpolationFactor = Math.max(0, 1.0 - (distanceToCurrent / 3.0)) * parentModule.corneringFactor.getValue();
            rotationTarget = rotationTarget.add(nextTargetVec.subtract(rotationTarget).scale(interpolationFactor));
        }

        RotationUtil.faceVector(rotationTarget, (float) parentModule.rotationSpeed.getValue(), (float) parentModule.headNodStrength.getValue(), (float) parentModule.headShakeStrength.getValue());

        KeyBinding.set(mc.options.keyJump.getKey(), false);

        boolean shouldSprint = !mc.level.getBlockState(mc.player.blockPosition().below()).is(Blocks.SOUL_SAND);

        // Wyłącz sprint pod niskim sufitem
        if (parentModule.avoidHeadHitters.isEnabled() && mc.level.getBlockState(mc.player.blockPosition().above(2)).isSolidRender(mc.level, mc.player.blockPosition().above(2))) {
            shouldSprint = false;
        }

        boolean isFinalLeg = currentIndex >= path.size() - 2;
        if (isFinalLeg) {
            shouldSprint = false;
        }

        float yawDifference = Math.abs(mc.player.yRot - RotationUtil.getTargetYaw(mc.player.position(), rotationTarget));
        if (yawDifference > 30.0 * parentModule.slowdownFactor.getValue()) {
            shouldSprint = false;
        }
        KeyBinding.set(mc.options.keySprint.getKey(), shouldSprint);

        if (mc.player.isInWater()) KeyBinding.set(mc.options.keyJump.getKey(), true);
        else if (mc.level.getBlockState(mc.player.blockPosition()).is(Blocks.LADDER) && targetPos.getY() > mc.player.getY()) KeyBinding.set(mc.options.keyUp.getKey(), true);
        else if (targetPos.getY() > mc.player.blockPosition().getY() && mc.player.isOnGround()) {
            mc.player.setDeltaMovement(mc.player.getDeltaMovement().x, parentModule.jumpHeight.getValue(), mc.player.getDeltaMovement().z);
        }

        KeyBinding.set(mc.options.keyUp.getKey(), true);
    }

    private void checkForDoors() {
        if (!parentModule.autoOpenDoors.isEnabled() || mc.player == null || mc.level == null) return;

        for (int x = -1; x <= 1; x++) {
            for (int y = -1; y <= 1; y++) {
                for (int z = -1; z <= 1; z++) {
                    BlockPos checkPos = mc.player.blockPosition().offset(x, y, z);
                    BlockState state = mc.level.getBlockState(checkPos);

                    boolean shouldOpen = false;
                    if (state.getBlock() instanceof DoorBlock && !state.getValue(DoorBlock.OPEN)) {
                        shouldOpen = true;
                    } else if (state.getBlock() instanceof FenceGateBlock && !state.getValue(FenceGateBlock.OPEN)) {
                        shouldOpen = true;
                    }

                    if (shouldOpen) {
                        BlockRayTraceResult hit = new BlockRayTraceResult(Vector3d.atCenterOf(checkPos), Direction.UP, checkPos, false);
                        mc.player.connection.send(new CPlayerTryUseItemOnBlockPacket(Hand.MAIN_HAND, hit));
                    }
                }
            }
        }
    }

    private void handleParkourJump(BlockPos fromPos, BlockPos toPos) {
        Vector3d targetVec = new Vector3d(toPos.getX() + 0.5, toPos.getY() + 0.5, toPos.getZ() + 0.5);
        RotationUtil.faceVector(targetVec, 1.0f, 0, 0);

        KeyBinding.set(mc.options.keySprint.getKey(), true);
        KeyBinding.set(mc.options.keyUp.getKey(), true);

        double edgeProximity = 0;
        if (toPos.getX() > fromPos.getX()) edgeProximity = mc.player.getX() - (fromPos.getX() + 0.7);
        else if (toPos.getX() < fromPos.getX()) edgeProximity = (fromPos.getX() + 0.3) - mc.player.getX();
        else if (toPos.getZ() > fromPos.getZ()) edgeProximity = mc.player.getZ() - (fromPos.getZ() + 0.7);
        else if (toPos.getZ() < fromPos.getZ()) edgeProximity = (fromPos.getZ() + 0.3) - mc.player.getZ();

        if (edgeProximity > 0 && mc.player.isOnGround()) {
            mc.player.jumpFromGround();
        }
    }
}