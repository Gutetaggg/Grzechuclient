package com.twojanazwa.grzechuclient.gui.clickgui;

import com.mojang.blaze3d.matrix.MatrixStack;
import com.twojanazwa.grzechuclient.gui.clickgui.components.ModuleButton;
import net.minecraft.client.gui.AbstractGui;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

public class Frame extends Component {
    private final String title;
    private final List<Component> components = new ArrayList<>();
    private boolean dragging;
    private int dragX, dragY;

    public Frame(String title, int x, int y) {
        this.title = title;
        this.x = x;
        this.y = y;
        this.width = 90;
        this.height = 18;
    }

    public void addComponent(Component component) {
        components.add(component);
    }

    @Override
    public void render(MatrixStack matrixStack, int mouseX, int mouseY, float partialTicks) {
        if (dragging) {
            x = mouseX - dragX;
            y = mouseY - dragY;
        }

        AbstractGui.fill(matrixStack, x, y, x + width, y + height, new Color(40, 40, 180, 220).getRGB());
        mc.font.draw(matrixStack, title, x + 3, y + 5, Color.WHITE.getRGB());

        int offsetY = height;
        for (Component component : components) {
            component.x = this.x;
            component.y = this.y + offsetY;
            component.render(matrixStack, mouseX, mouseY, partialTicks);
            if (component instanceof ModuleButton) {
                offsetY += ((ModuleButton) component).getTotalHeight();
            } else {
                offsetY += component.height;
            }
        }
    }

    @Override
    public void mouseClicked(double mouseX, double mouseY, int button) {
        if (isMouseOver(mouseX, mouseY) && mouseY < this.y + this.height && button == 0) {
            dragging = true;
            dragX = (int) (mouseX - x);
            dragY = (int) (mouseY - y);
        }

        for (Component component : components) {
            component.mouseClicked(mouseX, mouseY, button);
        }
    }

    @Override
    public void mouseReleased(double mouseX, double mouseY, int button) {
        if (button == 0) {
            dragging = false;
        }
        for (Component component : components) {
            component.mouseReleased(mouseX, mouseY, button);
        }
    }

    @Override
    public void mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        for (Component component : components) {
            component.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
        }
    }

    @Override
    public void keyTyped(int keyCode, int scanCode, int modifiers) {
        for (Component component : components) {
            component.keyTyped(keyCode, scanCode, modifiers);
        }
    }
}
