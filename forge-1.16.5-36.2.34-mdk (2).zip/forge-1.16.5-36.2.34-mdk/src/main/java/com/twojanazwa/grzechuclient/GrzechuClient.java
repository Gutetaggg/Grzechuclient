package com.twojanazwa.grzechuclient;

import com.twojanazwa.grzechuclient.core.Client;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Mod("grzechuclient")
public class GrzechuClient {

    public static final String MOD_ID = "grzechuclient";
    public static final Logger LOGGER = LogManager.getLogger();

    // Instancja naszego klienta
    public static Client client;

    public GrzechuClient() {
        // Inicjalizacja klienta
        client = new Client();
        client.initialize();

        // Rejestracja głównego obiektu klienta w systemie eventów Forge
        MinecraftForge.EVENT_BUS.register(this);
        MinecraftForge.EVENT_BUS.register(client); // Rejestrujemy też klienta, aby mógł słuchać eventów

        LOGGER.info("GrzechuClient został pomyślnie załadowany!");
    }
}