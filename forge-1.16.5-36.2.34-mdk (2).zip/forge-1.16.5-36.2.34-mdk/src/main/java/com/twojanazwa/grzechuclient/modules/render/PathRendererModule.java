package com.twojanazwa.grzechuclient.modules.render;

import com.mojang.blaze3d.matrix.MatrixStack;
import com.twojanazwa.grzechuclient.modules.Module;
import com.twojanazwa.grzechuclient.util.RenderUtil;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.vector.Vector3d;
import java.util.List;

public class PathRendererModule extends Module {

    private List<BlockPos> path;

    public PathRendererModule() {
        super("PathRenderer");
        // Ten moduł jest domyślnie włączony, bo tylko rysuje
        this.setEnabled(true);
    }

    public void setPath(List<BlockPos> path) {
        this.path = path;
    }

    public void onRender(MatrixStack matrixStack, float partialTicks) {
        if (!isEnabled() || path == null || path.isEmpty() || mc.player == null) {
            return;
        }

        Vector3d playerPos = mc.player.getEyePosition(partialTicks);
        RenderUtil.begin3D();

        for (int i = 0; i < path.size() - 1; i++) {
            BlockPos pos1 = path.get(i);
            BlockPos pos2 = path.get(i + 1);
            RenderUtil.drawLine(pos1, pos2, 0.2f, 0.8f, 1.0f, 1.0f, matrixStack);
        }

        RenderUtil.end3D();
    }
}