package com.twojanazwa.grzechuclient.util;

import net.minecraft.client.Minecraft;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.vector.Vector3d;
import java.util.Random;

public class RotationUtil {
    private static final Minecraft mc = Minecraft.getInstance();
    private static final Random random = new Random();

    public static void faceVector(Vector3d vec, float rotationSpeed, float nodStrength, float shakeStrength) {
        if (mc.player == null) return;

        float targetYaw = getTargetYaw(mc.player.position(), vec);

        // Dodajemy losowe drgania do docelowego yaw
        targetYaw += (random.nextFloat() - 0.5f) * shakeStrength;

        float currentYaw = MathHelper.wrapDegrees(mc.player.yRot);
        float finalYaw = MathHelper.wrapDegrees(MathHelper.lerp(rotationSpeed, currentYaw, targetYaw));

        // Obliczamy dynamiczny pitch (kiwanie głową)
        double time = (System.currentTimeMillis() % 4000L) / 4000.0 * 2 * Math.PI; // Pełen cykl co 4 sekundy
        float dynamicPitch = 7.5F + (float) (Math.sin(time) * nodStrength);

        mc.player.yRot = finalYaw;
        mc.player.xRot = dynamicPitch;
    }

    public static float getTargetYaw(Vector3d from, Vector3d to) {
        double diffX = to.x - from.x;
        double diffZ = to.z - from.z;
        return (float) (Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0F);
    }
}