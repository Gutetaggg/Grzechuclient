package com.twojanazwa.grzechuclient.util;

import com.mojang.blaze3d.matrix.MatrixStack;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.vector.Matrix4f;
import net.minecraft.util.math.vector.Vector3d;
import org.lwjgl.opengl.GL11;

public class RenderUtil {

    private static final Minecraft mc = Minecraft.getInstance();

    public static void begin3D() {
        RenderSystem.pushMatrix();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableTexture();
        RenderSystem.disableDepthTest();
        RenderSystem.depthMask(false);
        RenderSystem.disableCull();
        GL11.glEnable(GL11.GL_LINE_SMOOTH);
        GL11.glHint(GL11.GL_LINE_SMOOTH_HINT, GL11.GL_NICEST);
    }

    public static void end3D() {
        GL11.glDisable(GL11.GL_LINE_SMOOTH);
        RenderSystem.enableCull();
        RenderSystem.depthMask(true);
        RenderSystem.enableDepthTest();
        RenderSystem.enableTexture();
        RenderSystem.disableBlend();
        RenderSystem.popMatrix();
    }

    public static void drawLine(BlockPos p1, BlockPos p2, float r, float g, float b, float a, MatrixStack matrixStack) {
        // POPRAWKA: Użyto `getMainCamera().getPosition()`
        Vector3d camPos = mc.gameRenderer.getMainCamera().getPosition();

        double x1 = p1.getX() + 0.5 - camPos.x();
        double y1 = p1.getY() + 0.5 - camPos.y();
        double z1 = p1.getZ() + 0.5 - camPos.z();

        double x2 = p2.getX() + 0.5 - camPos.x();
        double y2 = p2.getY() + 0.5 - camPos.y();
        double z2 = p2.getZ() + 0.5 - camPos.z();

        // POPRAWKA: Użyto `getBuilder()`
        Tessellator tessellator = Tessellator.getInstance();
        BufferBuilder bufferBuilder = tessellator.getBuilder();

        // POPRAWKA: Użyto `last().pose()`
        Matrix4f matrix = matrixStack.last().pose();

        GL11.glLineWidth(2.0f);
        bufferBuilder.begin(GL11.GL_LINES, DefaultVertexFormats.POSITION_COLOR);
        // POPRAWKA: Użyto `vertex()` zamiast `pos()`
        bufferBuilder.vertex(matrix, (float)x1, (float)y1, (float)z1).color(r, g, b, a).endVertex();
        bufferBuilder.vertex(matrix, (float)x2, (float)y2, (float)z2).color(r, g, b, a).endVertex();

        // POPRAWKA: Użyto `tessellator.end()`
        tessellator.end();
    }
}