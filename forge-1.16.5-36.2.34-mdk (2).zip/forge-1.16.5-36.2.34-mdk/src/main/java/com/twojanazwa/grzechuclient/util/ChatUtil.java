package com.twojanazwa.grzechuclient.util;

import net.minecraft.client.Minecraft;
import net.minecraft.util.Util;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.util.text.TextFormatting;

public class ChatUtil {

    private static final Minecraft mc = Minecraft.getInstance();
    private static final String PREFIX = TextFormatting.AQUA + "[GrzechuClient] " + TextFormatting.RESET;

    public static void sendClientMessage(String message) {
        if (mc.player != null) {
            // POPRAWKA: Używamy oficjalnej nazwy mapowania: 'Util.NIL_UUID'
            mc.player.sendMessage(new StringTextComponent(PREFIX + message), Util.NIL_UUID);
        }
    }
}