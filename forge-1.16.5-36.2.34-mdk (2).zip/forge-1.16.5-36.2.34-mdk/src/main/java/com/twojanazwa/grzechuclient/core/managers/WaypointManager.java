package com.twojanazwa.grzechuclient.core.managers;

public class WaypointManager {
}
