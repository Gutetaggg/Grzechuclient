package com.twojanazwa.grzechuclient.gui.clickgui.components;

import com.mojang.blaze3d.matrix.MatrixStack;
import com.twojanazwa.grzechuclient.gui.clickgui.Component;
import com.twojanazwa.grzechuclient.settings.BooleanSetting;
import net.minecraft.client.gui.AbstractGui;
import java.awt.Color;

public class Checkbox extends Component {
    private final BooleanSetting setting;

    public Checkbox(BooleanSetting setting) {
        this.setting = setting;
        this.width = 90;
        this.height = 15;
    }

    @Override
    public void render(MatrixStack matrixStack, int mouseX, int mouseY, float partialTicks) {
        // Tło
        AbstractGui.fill(matrixStack, x, y, x + width, y + height, new Color(10, 10, 10, 180).getRGB());

        // Tekst i kwadracik
        mc.font.draw(matrixStack, setting.getName(), x + 18, y + 4, Color.WHITE.getRGB());
        AbstractGui.fill(matrixStack, x + 4, y + 4, x + 12, y + 12, new Color(40, 40, 40, 200).getRGB());
        if (setting.isEnabled()) {
            AbstractGui.fill(matrixStack, x + 5, y + 5, x + 11, y + 11, new Color(70, 70, 200, 200).getRGB());
        }
    }

    @Override
    public void mouseClicked(double mouseX, double mouseY, int button) {
        if (isMouseOver(mouseX, mouseY) && button == 0) {
            setting.toggle();
        }
    }
}