package com.twojanazwa.grzechuclient.settings;

import com.twojanazwa.grzechuclient.modules.Module;
import java.util.Arrays;
import java.util.List;

public class ModeSetting extends Setting {
    private String currentMode;
    private final List<String> modes;
    private int index;

    public ModeSetting(String name, Module parent, String defaultMode, String... modes) {
        super(name, parent);
        this.modes = Arrays.asList(modes);
        this.currentMode = defaultMode;
        this.index = this.modes.indexOf(defaultMode);
    }

    public String getMode() {
        return currentMode;
    }

    public void cycle() {
        index = (index + 1) % modes.size();
        currentMode = modes.get(index);
    }
}
