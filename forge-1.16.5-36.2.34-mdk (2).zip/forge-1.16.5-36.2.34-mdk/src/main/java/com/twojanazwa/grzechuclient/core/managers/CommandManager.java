package com.twojanazwa.grzechuclient.core.managers;

import com.twojanazwa.grzechuclient.commands.Command;
import com.twojanazwa.grzechuclient.commands.impl.GotoCommand;
import com.twojanazwa.grzechuclient.commands.impl.StopCommand; // Import
import com.twojanazwa.grzechuclient.util.ChatUtil;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class CommandManager {

    private final List<Command> commands = new ArrayList<>();
    private String prefix = "/";

    public CommandManager() {
        commands.add(new GotoCommand());
        commands.add(new StopCommand()); // Rejestracja nowej komendy
    }

    public void execute(String rawMessage) {
        String message = rawMessage.substring(prefix.length());
        String[] args = message.split(" ");
        String commandName = args[0];

        for (Command command : commands) {
            // Dodajemy aliasy, np. "s" dla "stop"
            if (command.getName().equalsIgnoreCase(commandName) || Arrays.asList(command.getAliases()).contains(commandName.toLowerCase())) {
                command.execute(Arrays.copyOfRange(args, 1, args.length));
                return;
            }
        }
        ChatUtil.sendClientMessage("Nie znaleziono komendy: " + commandName);
    }

    public String getPrefix() {
        return prefix;
    }

    public void setPrefix(String prefix) {
        this.prefix = prefix;
    }
}