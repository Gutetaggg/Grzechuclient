package com.twojanazwa.grzechuclient.pathfinding;

import net.minecraft.util.math.BlockPos;

public class PathNode {
    private final BlockPos pos;
    private PathNode parent;
    private double gCost;
    private double hCost;
    private double fCost;

    public PathNode(BlockPos pos) {
        this.pos = pos;
    }

    public BlockPos getPos() { return pos; }
    public PathNode getParent() { return parent; }
    public double getFCost() { return fCost; }
    // POPRAWKA: Dodano brakujący getter
    public double getGCost() { return gCost; }

    public void setParent(PathNode parent) { this.parent = parent; }
    public void setGCost(double gCost) { this.gCost = gCost; }
    public void setHCost(double hCost) { this.hCost = hCost; }
    public void calculateFCost() { this.fCost = this.gCost + this.hCost; }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        return pos.equals(((PathNode) obj).pos);
    }

    @Override
    public int hashCode() {
        return pos.hashCode();
    }
}
