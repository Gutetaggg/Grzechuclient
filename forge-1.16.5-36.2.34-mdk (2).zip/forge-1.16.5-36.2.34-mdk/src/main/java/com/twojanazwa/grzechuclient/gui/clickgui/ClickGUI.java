package com.twojanazwa.grzechuclient.gui.clickgui;

import com.mojang.blaze3d.matrix.MatrixStack;
import com.twojanazwa.grzechuclient.GrzechuClient;
import com.twojanazwa.grzechuclient.gui.clickgui.components.KeybindButton;
import com.twojanazwa.grzechuclient.gui.clickgui.components.ModuleButton;
import com.twojanazwa.grzechuclient.modules.Module;
import com.twojanazwa.grzechuclient.util.KeybindManager;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.util.text.StringTextComponent;
import java.util.ArrayList;
import java.util.List;

public class ClickGUI extends Screen {
    private static ClickGUI instance;
    private final List<Frame> frames = new ArrayList<>();

    private ClickGUI() {
        super(new StringTextComponent("GrzechuClient ClickGUI"));

        // Ramka z modułami
        Frame mainFrame = new Frame("Moduły", 20, 20);
        for (Module module : GrzechuClient.client.getModuleManager().getModules()) {
            mainFrame.addComponent(new ModuleButton(module));
        }
        frames.add(mainFrame);

        // NOWA RAMKA: Keybindy
        Frame keybindFrame = new Frame("Keybinds", 120, 20);
        for (KeybindManager.Keybind keybind : GrzechuClient.client.keybindManager.getKeybinds()) {
            keybindFrame.addComponent(new KeybindButton(keybind));
        }
        frames.add(keybindFrame);
    }

    public static void reinit() {
        instance = new ClickGUI();
    }

    public static ClickGUI getInstance() {
        if (instance == null) {
            instance = new ClickGUI();
        }
        return instance;
    }

    @Override
    public void render(MatrixStack matrixStack, int mouseX, int mouseY, float partialTicks) {
        for (Frame frame : frames) {
            frame.render(matrixStack, mouseX, mouseY, partialTicks);
        }
        super.render(matrixStack, mouseX, mouseY, partialTicks);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        for (Frame frame : frames) {
            frame.mouseClicked(mouseX, mouseY, button);
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        for (Frame frame : frames) {
            frame.mouseReleased(mouseX, mouseY, button);
        }
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        for (Frame frame : frames) {
            frame.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
        }
        return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        for (Frame frame : frames) {
            frame.keyTyped(keyCode, scanCode, modifiers);
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}