package com.twojanazwa.grzechuclient.gui.clickgui.components;

import com.mojang.blaze3d.matrix.MatrixStack;
import com.twojanazwa.grzechuclient.gui.clickgui.Component;
import com.twojanazwa.grzechuclient.modules.Module;
import com.twojanazwa.grzechuclient.settings.BooleanSetting;
import com.twojanazwa.grzechuclient.settings.DoubleSetting;
import com.twojanazwa.grzechuclient.settings.ModeSetting;
import com.twojanazwa.grzechuclient.settings.Setting;
import net.minecraft.client.gui.AbstractGui;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

public class ModuleButton extends Component {
    private final Module module;
    private final List<Component> subComponents = new ArrayList<>();
    private boolean open;

    public ModuleButton(Module module) {
        this.module = module;
        this.width = 90;
        this.height = 15;
        this.open = false;

        for (Setting setting : module.getSettings()) {
            if (setting instanceof DoubleSetting) {
                subComponents.add(new Slider((DoubleSetting) setting));
            } else if (setting instanceof BooleanSetting) {
                subComponents.add(new Checkbox((BooleanSetting) setting));
            } else if (setting instanceof ModeSetting) {
                subComponents.add(new ModeButton((ModeSetting) setting));
            }
        }
    }

    // ... reszta klasy bez zmian
    @Override
    public void render(MatrixStack matrixStack, int mouseX, int mouseY, float partialTicks) {
        int bgColor = module.isEnabled() ? new Color(50, 150, 255, 200).getRGB() : new Color(30, 30, 30, 200).getRGB();
        AbstractGui.fill(matrixStack, x, y, x + width, y + height, bgColor);

        String name = module.getName();
        int textX = x + (width - mc.font.width(name)) / 2;
        int textY = y + (height - mc.font.lineHeight) / 2 + 1;
        mc.font.draw(matrixStack, name, textX, textY, Color.WHITE.getRGB());

        if (open) {
            int subY = this.height;
            for (Component comp : subComponents) {
                comp.x = this.x;
                comp.y = this.y + subY;
                comp.render(matrixStack, mouseX, mouseY, partialTicks);
                subY += comp.height;
            }
        }
    }

    @Override
    public void mouseClicked(double mouseX, double mouseY, int button) {
        boolean isOverMainButton = mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + height;

        if (isOverMainButton) {
            if (button == 0) {
                module.toggle();
            } else if (button == 1) {
                if (!subComponents.isEmpty()) {
                    open = !open;
                }
            }
            return;
        }

        if (open) {
            for (Component comp : subComponents) {
                comp.mouseClicked(mouseX, mouseY, button);
            }
        }
    }

    @Override
    public void mouseReleased(double mouseX, double mouseY, int button) {
        if (open) {
            for (Component comp : subComponents) {
                comp.mouseReleased(mouseX, mouseY, button);
            }
        }
    }

    @Override
    public void mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (open) {
            for (Component comp : subComponents) {
                comp.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
            }
        }
    }

    public int getTotalHeight() {
        if (!open) {
            return height;
        }
        int total = height;
        for (Component comp : subComponents) {
            total += comp.height;
        }
        return total;
    }
}