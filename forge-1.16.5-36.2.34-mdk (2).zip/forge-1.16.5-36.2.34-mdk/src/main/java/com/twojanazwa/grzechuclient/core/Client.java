package com.twojanazwa.grzechuclient.core;

import com.twojanazwa.grzechuclient.core.managers.CommandManager;
import com.twojanazwa.grzechuclient.core.managers.ModuleManager;
import com.twojanazwa.grzechuclient.gui.clickgui.ClickGUI;
import com.twojanazwa.grzechuclient.util.ChatUtil;
import com.twojanazwa.grzechuclient.util.KeybindManager;
import net.minecraft.client.Minecraft;
import net.minecraftforge.client.event.ClientChatEvent;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import org.lwjgl.glfw.GLFW;

public class Client {

    private final Minecraft mc = Minecraft.getInstance();
    private ModuleManager moduleManager;
    private CommandManager commandManager;
    public KeybindManager keybindManager; // Publiczny, aby GUI miało dostęp

    public void initialize() {
        moduleManager = new ModuleManager();
        commandManager = new CommandManager();
        keybindManager = new KeybindManager();
        ChatUtil.sendClientMessage("Inicjalizacja menedżerów zakończona.");
    }

    public ModuleManager getModuleManager() {
        return moduleManager;
    }

    @SubscribeEvent
    public void onKeyInput(InputEvent.KeyInputEvent event) {
        if (mc.screen == null && event.getAction() == GLFW.GLFW_PRESS) {
            // Używamy klawiszy z menedżera
            if (event.getKey() == keybindManager.openGui.getKey()) {
                mc.setScreen(ClickGUI.getInstance());
            }
            if (event.getKey() == keybindManager.pausePath.getKey()) {
                moduleManager.getPathfindingModule().getExecutor().togglePause();
            }
        }
    }

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public void onChat(ClientChatEvent event) {
        String message = event.getMessage();
        if (message.startsWith(commandManager.getPrefix())) {
            event.setCanceled(true);
            commandManager.execute(message);
        }
    }

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase == TickEvent.Phase.END && mc.player != null) {
            moduleManager.getPathfindingModule().onTick();
        }
    }

    @SubscribeEvent
    public void onRenderWorld(RenderWorldLastEvent event) {
        if (mc.player == null || mc.level == null) return;
        moduleManager.getPathRendererModule().onRender(event.getMatrixStack(), event.getPartialTicks());
    }

    @SubscribeEvent
    public void onRenderOverlay(RenderGameOverlayEvent.Text event) {
        moduleManager.getHudModule().onRenderOverlay(event.getMatrixStack());
    }
}