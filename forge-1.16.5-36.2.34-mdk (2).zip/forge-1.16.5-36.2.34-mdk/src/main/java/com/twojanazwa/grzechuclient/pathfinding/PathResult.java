package com.twojanazwa.grzechuclient.pathfinding;

import net.minecraft.util.math.BlockPos;
import java.util.List;
import java.util.Optional;

public class PathResult {

    public enum FailureReason {
        TIMEOUT("Przekroczono czas obliczeń. Cel jest zbyt daleko lub trasa jest zbyt skomplikowana."),
        GOAL_OBSTRUCTED("Cel jest wewnątrz ściany lub jest niedostępny."),
        NO_PATH_FOUND("Nie znaleziono żadnej możliwej ścieżki do celu.");

        private final String message;
        FailureReason(String message) { this.message = message; }
        public String getMessage() { return message; }
    }

    private final List<BlockPos> path;
    private final FailureReason failureReason;

    private PathResult(List<BlockPos> path, FailureReason failureReason) {
        this.path = path;
        this.failureReason = failureReason;
    }

    public static PathResult success(List<BlockPos> path) {
        return new PathResult(path, null);
    }

    public static PathResult failure(FailureReason reason) {
        return new PathResult(null, reason);
    }

    public boolean isSuccessful() {
        return path != null;
    }

    public Optional<List<BlockPos>> getPath() {
        return Optional.ofNullable(path);
    }

    public Optional<FailureReason> getFailureReason() {
        return Optional.ofNullable(failureReason);
    }
}