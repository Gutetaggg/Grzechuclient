package com.twojanazwa.grzechuclient.modules.render;

import com.mojang.blaze3d.matrix.MatrixStack;
import com.twojanazwa.grzechuclient.GrzechuClient;
import com.twojanazwa.grzechuclient.modules.Module;
import com.twojanazwa.grzechuclient.modules.movement.PathfindingModule;
import com.twojanazwa.grzechuclient.settings.BooleanSetting;
import com.twojanazwa.grzechuclient.settings.DoubleSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.vector.Vector3d;

import java.awt.Color;
import java.util.List;

public class HudModule extends Module {

    private final Minecraft mc = Minecraft.getInstance();
    public final BooleanSetting showHud = new BooleanSetting("Pokazuj HUD", this, true);
    public final DoubleSetting hudX = new DoubleSetting("HUD X", this, 2, 0, 1000);
    public final DoubleSetting hudY = new DoubleSetting("HUD Y", this, 2, 0, 1000);

    public HudModule() {
        super("HUD");
        this.setEnabled(true); // HUD jest zawsze aktywny, ale rysuje się tylko, gdy showHud jest włączone
        addSetting(showHud);
        addSetting(hudX);
        addSetting(hudY);
    }

    public void onRenderOverlay(MatrixStack matrixStack) {
        if (!showHud.isEnabled() || mc.player == null) {
            return;
        }

        PathfindingModule pathfinder = GrzechuClient.client.getModuleManager().getPathfindingModule();
        if (!pathfinder.getExecutor().isActive()) {
            return;
        }

        List<BlockPos> path = pathfinder.getExecutor().getPath();
        int currentIndex = pathfinder.getExecutor().getCurrentIndex();
        if (path == null || currentIndex >= path.size()) {
            return;
        }

        // Obliczenia
        double distance = calculateRemainingDistance(path, currentIndex);
        String eta = calculateETA(distance);
        BlockPos nextPoint = path.get(currentIndex);
        boolean isPaused = pathfinder.getExecutor().isPaused();

        // Rysowanie
        int x = (int) hudX.getValue();
        int y = (int) hudY.getValue();
        int color = Color.WHITE.getRGB();

        mc.font.draw(matrixStack, "GrzechuClient Nawigacja", x, y, color);
        mc.font.draw(matrixStack, String.format("Dystans: %.1f m", distance), x, y + 10, color);
        mc.font.draw(matrixStack, "ETA: " + eta, x, y + 20, color);
        mc.font.draw(matrixStack, String.format("Następny punkt: %d, %d, %d", nextPoint.getX(), nextPoint.getY(), nextPoint.getZ()), x, y + 30, color);
        if (isPaused) {
            mc.font.draw(matrixStack, "[PAUZA]", x, y + 40, Color.YELLOW.getRGB());
        }
    }

    private double calculateRemainingDistance(List<BlockPos> path, int currentIndex) {
        if (mc.player == null) return 0;
        double totalDist = 0;
        Vector3d currentPos = mc.player.position();

        // Dystans od gracza do pierwszego punktu
        if (currentIndex < path.size()) {
            BlockPos firstPoint = path.get(currentIndex);
            totalDist += currentPos.distanceTo(new Vector3d(firstPoint.getX() + 0.5, firstPoint.getY() + 0.5, firstPoint.getZ() + 0.5));
        }

        // Dystans między kolejnymi punktami
        for (int i = currentIndex; i < path.size() - 1; i++) {
            BlockPos p1 = path.get(i);
            BlockPos p2 = path.get(i + 1);
            totalDist += Math.sqrt(p1.distSqr(p2));
        }
        return totalDist;
    }

    private String calculateETA(double distance) {
        if (mc.player == null) return "0s";
        double speed = mc.player.getSpeed() * 20; // Prędkość w blokach/sekundę
        if (speed < 0.1) speed = 4.3; // Domyślna prędkość chodzenia, jeśli stoimy w miejscu
        if (mc.player.isSprinting()) speed = 5.6;

        int seconds = (int) (distance / speed);
        int minutes = seconds / 60;
        seconds %= 60;

        return String.format("%dm %ds", minutes, seconds);
    }
}